$(document).ready(function () {
  $(".liked_bt").click(function () {
    $(this).toggleClass("active");
  });
});
