<?php

switch ($nrCat) {
    case "cat-todos":
        $nrCat = "Todos os produtos";
        break;
    case "cat-1":
        $nrCat = "Aplicações";
        break;
    case "cat-2":
        $nrCat = "Chat";
        break;
    case "cat-3":
        $nrCat = "Gestão de API";
        break;
    case "cat-4":
        $nrCat = "Qualidade de Código";
        break;
    case "cat-5":
        $nrCat = "Revisão de Código";
        break;
    default:
        $nrCat = "ERRO!";
        break;
}

?>