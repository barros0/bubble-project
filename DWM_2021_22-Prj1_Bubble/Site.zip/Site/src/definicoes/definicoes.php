<?php include 'page_parts/header.php'; ?>

<div class="definicoes">
    <div class="esquerda_opcoes">
        <h3>Definições</h3>
        <div class="opcoes_definicoes">
            <ul>
                <li><a href="definicoes_geral.php"><i class='bx bxs-wrench'></i>Geral</a></li>
                <li><a href="definicoes_seguranca.php"><i class='bx bx-key'></i>Segurança</a></li>
                <li><a href="definicoes_suporte.php"><i class='bx bx-support'></i>Caixa de entrada de Suporte</a></li>
            </ul>
        </div>