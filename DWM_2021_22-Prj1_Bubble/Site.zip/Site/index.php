<?php

header('location:feed.php');
exit;