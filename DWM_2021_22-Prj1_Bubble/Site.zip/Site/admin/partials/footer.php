<script src="./public/js/faqs.js"></script>
<script src="./public/js/paginas.js"></script>
<script src="./public/js/eventos.js"></script>
</body>

</html>


<?php
