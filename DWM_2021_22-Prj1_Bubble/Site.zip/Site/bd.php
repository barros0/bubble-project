<?php
$host="localhost";
$database="mica_bubble";
$user="mica_bubble";
$pass='bubble2020';

$conn = new mysqli($host, $user, $pass, $database);

if ($conn->connect_errno) {
    $code = $conn->connect_errno;
    $message = $conn->connect_error;
    printf("<p>Connection error: %d %s</p>", $code, $message);
    exit;
    }

?>